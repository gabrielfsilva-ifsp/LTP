from datetime import datetime

from sqlalchemy import Column, String, Text

from database.db import Base


class Mensagem(Base):
    __tablename__ = "mensagens"

    remetentes_validos = ["user", "luna"]

    id = Column(String(64), primary_key=True)
    conteudo = Column(Text, default="")
    remetente = Column(String(16), default="user")
    criado_em = Column(String(40), default=lambda: datetime.now().isoformat())

    def __init__(self, id, conteudo, remetente="user", criado_em=None):
        self.id = id
        self.conteudo = conteudo.strip() if (conteudo and hasattr(conteudo, "strip")) else (conteudo or "")
        self.remetente = remetente
        self.criado_em = criado_em or datetime.now().isoformat()

    def __str__(self):
        preview = self.conteudo[:60] + "..." if len(self.conteudo) > 60 else self.conteudo
        return f"Mensagem[id={self.id}, remetente={self.remetente!r}, conteudo={preview!r}]"

    def __repr__(self):
        return self.__str__()

    def to_dict(self):
        return {
            "id": self.id,
            "conteudo": self.conteudo,
            "remetente": self.remetente,
            "criado_em": self.criado_em,
        }
