from datetime import datetime

from sqlalchemy import Column, String

from database.db import Base


class Amizade(Base):
    __tablename__ = "amizades"

    status_validos = ["pendente", "aceita", "recusada"]

    id = Column(String(64), primary_key=True)
    solicitante_id = Column(String(64), nullable=False)
    alvo_id = Column(String(64), nullable=False)
    status = Column(String(32), default="pendente")
    criado_em = Column(String(40), default=lambda: datetime.now().isoformat())

    def __init__(self, id, solicitante_id, alvo_id, status="pendente", criado_em=None):
        self.id = id
        self.solicitante_id = solicitante_id
        self.alvo_id = alvo_id
        self.status = status or "pendente"
        self.criado_em = criado_em or datetime.now().isoformat()

    def __str__(self):
        return (
            f"Amizade[id={self.id}, de={self.solicitante_id} → {self.alvo_id}, "
            f"status={self.status!r}]"
        )

    def __repr__(self):
        return self.__str__()

    def aceitar(self):
        if self.status == "pendente":
            self.status = "aceita"
            return True
        return False

    def recusar(self):
        if self.status == "pendente":
            self.status = "recusada"
            return True
        return False

    def to_dict(self):
        return {
            "id": self.id,
            "solicitante_id": self.solicitante_id,
            "alvo_id": self.alvo_id,
            "status": self.status,
            "criado_em": self.criado_em,
        }
