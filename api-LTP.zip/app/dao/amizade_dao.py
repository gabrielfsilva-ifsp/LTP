import uuid

from sqlalchemy import text

from database.db import get_session
from app.models.amizade import Amizade


AMIZADE_COLS = "id, solicitante_id, alvo_id, status, criado_em"


def _row_to_amizade(row):
    if row is None:
        return None
    return Amizade(**dict(row._mapping))


class AmizadeDAO:

    def listar_todos(self):
        with get_session() as session:
            rows = session.execute(text(f"SELECT {AMIZADE_COLS} FROM amizades ORDER BY id")).fetchall()
        return [_row_to_amizade(r) for r in rows]

    def buscar_por_id(self, id):
        with get_session() as session:
            row = session.execute(
                text(f"SELECT {AMIZADE_COLS} FROM amizades WHERE id = :id"),
                {"id": id}
            ).fetchone()
        return _row_to_amizade(row)

    def inserir(self, amizade):
        if not amizade.id:
            amizade.id = str(uuid.uuid4())

        with get_session() as session:
            session.execute(text(f"""
                INSERT INTO amizades ({AMIZADE_COLS})
                VALUES (:id, :solicitante_id, :alvo_id, :status, :criado_em)
            """), {
                "id": amizade.id,
                "solicitante_id": amizade.solicitante_id,
                "alvo_id": amizade.alvo_id,
                "status": amizade.status,
                "criado_em": amizade.criado_em,
            })
            session.commit()
        return amizade

    def atualizar_status(self, id, novo_status):
        amizade = self.buscar_por_id(id)
        if not amizade:
            return None

        if novo_status == "aceita":
            if not amizade.aceitar():
                return None
        elif novo_status == "recusada":
            if not amizade.recusar():
                return None
        else:
            return None

        with get_session() as session:
            result = session.execute(
                text("UPDATE amizades SET status = :status WHERE id = :id"),
                {"status": amizade.status, "id": id}
            )
            session.commit()
            if result.rowcount == 0:
                return None

        return self.buscar_por_id(id)

    def remover(self, id):
        amizade = self.buscar_por_id(id)
        if not amizade:
            return None
        with get_session() as session:
            session.execute(text("DELETE FROM amizades WHERE id = :id"), {"id": id})
            session.commit()
        return amizade


amizade_dao = AmizadeDAO()
