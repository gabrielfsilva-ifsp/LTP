import json
import uuid

from sqlalchemy import text

from database.db import get_session
from app.models.projeto import Projeto


PROJETO_COLS = (
    "id, nome, categoria, resumo, palavras_chave, introducao, objetivo_geral, "
    "objetivos_especificos, metodologia, cronograma, resultados_esperados, "
    "referencias_bibliograficas, status, criado_em"
)


def _row_to_projeto(row):
    if row is None:
        return None
    d = dict(row._mapping)
    oe = d.get("objetivos_especificos")
    d["objetivos_especificos"] = json.loads(oe) if isinstance(oe, str) else (oe or [])
    cr = d.get("cronograma")
    d["cronograma"] = json.loads(cr) if isinstance(cr, str) else (cr or {})
    return Projeto(**d)


class ProjetoDAO:

    def listar_todos(self):
        with get_session() as session:
            rows = session.execute(text(f"SELECT {PROJETO_COLS} FROM projetos ORDER BY id")).fetchall()
        return [_row_to_projeto(r) for r in rows]

    def buscar_por_id(self, id):
        with get_session() as session:
            row = session.execute(
                text(f"SELECT {PROJETO_COLS} FROM projetos WHERE id = :id"),
                {"id": id}
            ).fetchone()
        return _row_to_projeto(row)

    def inserir(self, projeto):
        if not projeto.id:
            projeto.id = str(uuid.uuid4())

        with get_session() as session:
            session.execute(text(f"""
                INSERT INTO projetos ({PROJETO_COLS})
                VALUES (:id, :nome, :categoria, :resumo, :palavras_chave, :introducao,
                    :objetivo_geral, :objetivos_especificos, :metodologia, :cronograma,
                    :resultados_esperados, :referencias_bibliograficas, :status, :criado_em)
            """), {
                "id": projeto.id,
                "nome": projeto.nome,
                "categoria": projeto.categoria,
                "resumo": projeto.resumo,
                "palavras_chave": projeto.palavras_chave,
                "introducao": projeto.introducao,
                "objetivo_geral": projeto.objetivo_geral,
                "objetivos_especificos": json.dumps(projeto.objetivos_especificos),
                "metodologia": projeto.metodologia,
                "cronograma": json.dumps(projeto.cronograma),
                "resultados_esperados": projeto.resultados_esperados,
                "referencias_bibliograficas": projeto.referencias_bibliograficas,
                "status": projeto.status,
                "criado_em": projeto.criado_em,
            })
            session.commit()
        return projeto

    def atualizar(self, id, dados):
        campos_editaveis = [
            "nome", "categoria", "resumo", "palavras_chave",
            "introducao", "objetivo_geral", "objetivos_especificos",
            "metodologia", "cronograma", "resultados_esperados",
            "referencias_bibliograficas", "status",
        ]

        set_clauses = []
        params = {"id": id}
        for campo in campos_editaveis:
            if campo in dados:
                valor = dados[campo]
                if campo in ("objetivos_especificos", "cronograma"):
                    valor = json.dumps(valor)
                set_clauses.append(f"{campo} = :{campo}")
                params[campo] = valor

        if not set_clauses:
            return self.buscar_por_id(id)

        sql = f"UPDATE projetos SET {', '.join(set_clauses)} WHERE id = :id"

        with get_session() as session:
            result = session.execute(text(sql), params)
            session.commit()
            if result.rowcount == 0:
                return None

        return self.buscar_por_id(id)

    def remover(self, id):
        projeto = self.buscar_por_id(id)
        if not projeto:
            return None
        with get_session() as session:
            session.execute(text("DELETE FROM projetos WHERE id = :id"), {"id": id})
            session.commit()
        return projeto


projeto_dao = ProjetoDAO()
