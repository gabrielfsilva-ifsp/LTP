import uuid

from sqlalchemy import text

from database.db import get_session
from app.models.mensagem import Mensagem


MENSAGEM_COLS = "id, conteudo, remetente, criado_em"


def _row_to_mensagem(row):
    if row is None:
        return None
    return Mensagem(**dict(row._mapping))


class MensagemDAO:

    def listar_todos(self):
        with get_session() as session:
            rows = session.execute(text(f"SELECT {MENSAGEM_COLS} FROM mensagens ORDER BY criado_em")).fetchall()
        return [_row_to_mensagem(r) for r in rows]

    def buscar_por_id(self, id):
        with get_session() as session:
            row = session.execute(
                text(f"SELECT {MENSAGEM_COLS} FROM mensagens WHERE id = :id"),
                {"id": id}
            ).fetchone()
        return _row_to_mensagem(row)

    def inserir(self, mensagem):
        if not mensagem.id:
            mensagem.id = str(uuid.uuid4())

        with get_session() as session:
            session.execute(text(f"""
                INSERT INTO mensagens ({MENSAGEM_COLS})
                VALUES (:id, :conteudo, :remetente, :criado_em)
            """), {
                "id": mensagem.id,
                "conteudo": mensagem.conteudo,
                "remetente": mensagem.remetente,
                "criado_em": mensagem.criado_em,
            })
            session.commit()
        return mensagem

    def atualizar(self, id, dados):
        campos_editaveis = ["conteudo", "remetente"]

        set_clauses = []
        params = {"id": id}
        for campo in campos_editaveis:
            if campo in dados:
                set_clauses.append(f"{campo} = :{campo}")
                params[campo] = dados[campo]

        if not set_clauses:
            return self.buscar_por_id(id)

        sql = f"UPDATE mensagens SET {', '.join(set_clauses)} WHERE id = :id"

        with get_session() as session:
            result = session.execute(text(sql), params)
            session.commit()
            if result.rowcount == 0:
                return None

        return self.buscar_por_id(id)

    def remover(self, id):
        mensagem = self.buscar_por_id(id)
        if not mensagem:
            return None
        with get_session() as session:
            session.execute(text("DELETE FROM mensagens WHERE id = :id"), {"id": id})
            session.commit()
        return mensagem


mensagem_dao = MensagemDAO()
