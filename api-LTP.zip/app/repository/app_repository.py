from database.db import Base, engine, get_session
from database.db import seed_db as _seed_db_default


class AppRepository:

    def resetar_e_seed(self):
        Base.metadata.drop_all(bind=engine)
        Base.metadata.create_all(bind=engine)

        _seed_db_default()

        with get_session() as session:
            from sqlalchemy import text
            qtd_p = session.execute(text("SELECT COUNT(*) FROM projetos")).scalar()
            qtd_a = session.execute(text("SELECT COUNT(*) FROM amizades")).scalar()
            qtd_m = session.execute(text("SELECT COUNT(*) FROM mensagens")).scalar()

        return {
            "tabelas_recriadas": list(Base.metadata.tables.keys()),
            "projetos_inseridos": qtd_p,
            "amizades_inseridas": qtd_a,
            "mensagens_inseridas": qtd_m,
            "status": "ok",
        }

    def estatisticas(self):
        from sqlalchemy import text
        with get_session() as session:
            qtd_projetos = session.execute(text("SELECT COUNT(*) FROM projetos")).scalar()
            qtd_amizades = session.execute(text("SELECT COUNT(*) FROM amizades")).scalar()
            qtd_aceitas = session.execute(text("SELECT COUNT(*) FROM amizades WHERE status = 'aceita'")).scalar()
            qtd_pendentes = session.execute(text("SELECT COUNT(*) FROM amizades WHERE status = 'pendente'")).scalar()
            qtd_recusadas = session.execute(text("SELECT COUNT(*) FROM amizades WHERE status = 'recusada'")).scalar()
            qtd_mensagens = session.execute(text("SELECT COUNT(*) FROM mensagens")).scalar()
            qtd_user = session.execute(text("SELECT COUNT(*) FROM mensagens WHERE remetente = 'user'")).scalar()
            qtd_luna = session.execute(text("SELECT COUNT(*) FROM mensagens WHERE remetente = 'luna'")).scalar()

        return {
            "projetos": {"total": qtd_projetos},
            "amizades": {
                "total": qtd_amizades,
                "aceitas": qtd_aceitas,
                "pendentes": qtd_pendentes,
                "recusadas": qtd_recusadas,
            },
            "mensagens": {
                "total": qtd_mensagens,
                "user": qtd_user,
                "luna": qtd_luna,
            },
        }


app_repository = AppRepository()
