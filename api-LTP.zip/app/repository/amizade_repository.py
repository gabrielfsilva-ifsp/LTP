from app.dao.amizade_dao import amizade_dao
from app.models.amizade import Amizade


class AmizadeRepository:

    def listar_todos(self):
        return amizade_dao.listar_todos()

    def buscar_por_id(self, id):
        return amizade_dao.buscar_por_id(id)

    def inserir(self, amizade):
        return amizade_dao.inserir(amizade)

    def atualizar_status(self, id, novo_status):
        return amizade_dao.atualizar_status(id, novo_status)

    def remover(self, id):
        return amizade_dao.remover(id)


amizade_repository = AmizadeRepository()
