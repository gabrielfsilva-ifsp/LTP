from app.dao.projeto_dao import projeto_dao
from app.models.projeto import Projeto


class ProjetoRepository:

    def listar_todos(self):
        return projeto_dao.listar_todos()

    def buscar_por_id(self, id):
        return projeto_dao.buscar_por_id(id)

    def inserir(self, projeto):
        return projeto_dao.inserir(projeto)

    def atualizar(self, id, dados):
        return projeto_dao.atualizar(id, dados)

    def remover(self, id):
        return projeto_dao.remover(id)


projeto_repository = ProjetoRepository()
