from app.dao.mensagem_dao import mensagem_dao
from app.models.mensagem import Mensagem


class MensagemRepository:

    def listar_todos(self):
        return mensagem_dao.listar_todos()

    def buscar_por_id(self, id):
        return mensagem_dao.buscar_por_id(id)

    def inserir(self, mensagem):
        return mensagem_dao.inserir(mensagem)

    def atualizar(self, id, dados):
        return mensagem_dao.atualizar(id, dados)

    def remover(self, id):
        return mensagem_dao.remover(id)


mensagem_repository = MensagemRepository()
