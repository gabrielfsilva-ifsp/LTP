from flask import Blueprint, jsonify, request

from app.services.mensagem_service import mensagem_service

mensagem_bp = Blueprint("mensagens", __name__, url_prefix="/api/mensagens")


@mensagem_bp.route("", methods=["GET"])
def get_mensagens():
    return jsonify(mensagem_service.listar_mensagens()), 200


@mensagem_bp.route("/<string:id>", methods=["GET"])
def get_mensagem(id):
    mensagem = mensagem_service.buscar_mensagem(id)
    if not mensagem:
        return jsonify({"erro": f"Mensagem '{id}' não encontrada."}), 404
    return jsonify(mensagem), 200


@mensagem_bp.route("", methods=["POST"])
def post_mensagem():
    dados = request.get_json()
    if not dados:
        return jsonify({"erro": "Body JSON obrigatório."}), 400

    mensagem, erro = mensagem_service.criar_mensagem(dados)
    if erro:
        return jsonify({"erro": erro}), 400

    return jsonify(mensagem), 201


@mensagem_bp.route("/<string:id>", methods=["PUT"])
def put_mensagem(id):
    dados = request.get_json()
    if not dados:
        return jsonify({"erro": "Body JSON obrigatório."}), 400

    mensagem, erro = mensagem_service.atualizar_mensagem(id, dados)
    if erro:
        return jsonify({"erro": erro}), 400
    if mensagem is None:
        return jsonify({"erro": f"Mensagem '{id}' não encontrada."}), 404

    return jsonify(mensagem), 200


@mensagem_bp.route("/<string:id>", methods=["DELETE"])
def delete_mensagem(id):
    mensagem = mensagem_service.remover_mensagem(id)
    if not mensagem:
        return jsonify({"erro": f"Mensagem '{id}' não encontrada."}), 404
    return jsonify(mensagem), 200
