from flask import Blueprint, jsonify

from app.repository.app_repository import app_repository

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


@admin_bp.route("/estatisticas", methods=["GET"])
def get_estatisticas():
    return jsonify(app_repository.estatisticas()), 200


@admin_bp.route("/reset", methods=["POST"])
def post_reset():
    resultado = app_repository.resetar_e_seed()
    return jsonify(resultado), 200
