import uuid

from app.models.mensagem import Mensagem
from app.repository.mensagem_repository import mensagem_repository


class MensagemService:

    def listar_mensagens(self):
        mensagens = mensagem_repository.listar_todos()
        return [m.to_dict() for m in mensagens]

    def buscar_mensagem(self, id):
        mensagem = mensagem_repository.buscar_por_id(id)
        if not mensagem:
            return None
        return mensagem.to_dict()

    def criar_mensagem(self, dados):
        conteudo = dados.get("conteudo", "")
        remetente = dados.get("remetente", "user")

        if not isinstance(conteudo, str) or not conteudo.strip():
            return None, "O campo 'conteudo' é obrigatório e não pode ser vazio."

        if remetente not in Mensagem.remetentes_validos:
            return None, (
                f"Remetente inválido: '{remetente}'. "
                f"Use um de: {Mensagem.remetentes_validos}"
            )

        mensagem = Mensagem(
            id=str(uuid.uuid4()),
            conteudo=conteudo.strip(),
            remetente=remetente,
        )

        mensagem_repository.inserir(mensagem)
        return mensagem.to_dict(), None

    def atualizar_mensagem(self, id, dados):
        if not dados:
            return None, "Nenhum dado enviado para atualização."

        if "conteudo" in dados:
            conteudo = dados["conteudo"]
            if not isinstance(conteudo, str) or not conteudo.strip():
                return None, "O campo 'conteudo' não pode ser vazio."

        if "remetente" in dados and dados["remetente"] not in Mensagem.remetentes_validos:
            return None, (
                f"Remetente inválido: '{dados['remetente']}'. "
                f"Use um de: {Mensagem.remetentes_validos}"
            )

        mensagem = mensagem_repository.atualizar(id, dados)

        if mensagem is None:
            return None, None

        return mensagem.to_dict(), None

    def remover_mensagem(self, id):
        mensagem = mensagem_repository.remover(id)
        if not mensagem:
            return None
        return mensagem.to_dict()


mensagem_service = MensagemService()
