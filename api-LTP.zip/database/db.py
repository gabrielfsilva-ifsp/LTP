import os
import json
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker


DATABASE_URL = "sqlite:///if_orbit.db"

engine = create_engine(
    DATABASE_URL,
    echo=False,
    future=True,
    connect_args={"check_same_thread": False},
)

SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
    future=True,
)


class Base(DeclarativeBase):
    pass


def init_db():
    from app.models import amizade
    from app.models import mensagem
    from app.models import projeto

    Base.metadata.create_all(bind=engine)


def seed_db():
    with get_session() as session:
        if session.execute(text("SELECT COUNT(*) FROM projetos")).scalar() > 0 or session.execute(text("SELECT COUNT(*) FROM amizades")).scalar() > 0:
            return

        session.execute(text("""
            INSERT INTO projetos (id, nome, categoria, resumo, palavras_chave, introducao,
                objetivo_geral, objetivos_especificos, metodologia, cronograma,
                resultados_esperados, referencias_bibliograficas, status, criado_em)
            VALUES (:id, :nome, :categoria, :resumo, :palavras_chave, :introducao,
                :objetivo_geral, :objetivos_especificos, :metodologia, :cronograma,
                :resultados_esperados, :referencias_bibliograficas, :status, :criado_em)
        """), {
            "id": "proj-001",
            "nome": "Sistema de Monitoramento de Queimadas com IA",
            "categoria": "ciencias_natureza_exatas",
            "resumo": "Plataforma para detecção precoce de incêndios florestais usando imagens de satélite e redes neurais convolucionais.",
            "palavras_chave": "satélite, IA, queimadas, Cerrado, CNN",
            "introducao": "O Brasil enfrenta crises recorrentes de queimadas no Cerrado...",
            "objetivo_geral": "Reduzir o tempo de resposta a queimadas no Cerrado em 40% usando monitoramento via satélite.",
            "objetivos_especificos": json.dumps([
                "Coletar imagens de satélite em tempo real via NASA FIRMS",
                "Treinar modelo CNN para detecção de focos de calor",
                "Emitir alertas automáticos para brigadas locais",
            ]),
            "metodologia": "Uso de APIs de satélite (NASA FIRMS) + modelo CNN treinado com TensorFlow.",
            "cronograma": json.dumps({
                "atividades": [
                    {"nome": "Pesquisa Bibliográfica", "meses": [3, 4]},
                    {"nome": "Coleta de dados", "meses": [5, 6]},
                    {"nome": "Treinamento do modelo", "meses": [7, 8]},
                    {"nome": "Validação e relatório", "meses": [9, 10, 11]},
                ]
            }),
            "resultados_esperados": "Dashboard com mapa de calor e sistema de alertas via SMS.",
            "referencias_bibliograficas": "NASA FIRMS. Fire Information for Resource Management System. Disponível em: https://firms.modaps.eosdis.nasa.gov",
            "status": "em_andamento",
            "criado_em": "2026-05-10T10:00:00",
        })

        session.execute(text("""
            INSERT INTO projetos (id, nome, categoria, resumo, palavras_chave, introducao,
                objetivo_geral, objetivos_especificos, metodologia, cronograma,
                resultados_esperados, referencias_bibliograficas, status, criado_em)
            VALUES (:id, :nome, :categoria, :resumo, :palavras_chave, :introducao,
                :objetivo_geral, :objetivos_especificos, :metodologia, :cronograma,
                :resultados_esperados, :referencias_bibliograficas, :status, :criado_em)
        """), {
            "id": "proj-002",
            "nome": "App de Saúde Mental para Estudantes do IFSP",
            "categoria": "informatica",
            "resumo": "Aplicativo mobile com recursos de mindfulness e triagem de ansiedade (GAD-7) para universitários do IFSP.",
            "palavras_chave": "saúde mental, ansiedade, mindfulness, universitários, GAD-7",
            "introducao": "Estudantes universitários apresentam altas taxas de ansiedade...",
            "objetivo_geral": "Disponibilizar ferramenta digital acessível de suporte à saúde mental para estudantes.",
            "objetivos_especificos": json.dumps([
                "Implementar questionário de triagem GAD-7",
                "Desenvolver sessões guiadas de meditação",
                "Criar dashboard de acompanhamento emocional",
            ]),
            "metodologia": "Desenvolvimento mobile com React Native, backend Flask, banco SQLite.",
            "cronograma": json.dumps({
                "atividades": [
                    {"nome": "Levantamento de requisitos", "meses": [3, 4]},
                    {"nome": "Desenvolvimento do app", "meses": [5, 6, 7]},
                    {"nome": "Testes com usuários", "meses": [8, 9]},
                    {"nome": "Finalização", "meses": [10, 11]},
                ]
            }),
            "resultados_esperados": "App publicado na Play Store com 100 usuários no piloto.",
            "referencias_bibliograficas": "SPITZER, R. L. et al. A Brief Measure for Assessing Generalized Anxiety Disorder. Archives of Internal Medicine, 2006.",
            "status": "rascunho",
            "criado_em": "2026-05-20T14:30:00",
        })

        session.execute(text("""
            INSERT INTO amizades (id, solicitante_id, alvo_id, status, criado_em)
            VALUES (:id, :solicitante_id, :alvo_id, :status, :criado_em)
        """), [
            {"id": "amz-001", "solicitante_id": "user-A", "alvo_id": "user-B", "status": "aceita", "criado_em": "2026-05-15T09:00:00"},
            {"id": "amz-002", "solicitante_id": "user-C", "alvo_id": "user-A", "status": "pendente", "criado_em": "2026-06-01T16:20:00"},
        ])

        session.execute(text("""
            INSERT INTO mensagens (id, conteudo, remetente, criado_em)
            VALUES (:id, :conteudo, :remetente, :criado_em)
        """), [
            {"id": "msg-001", "conteudo": "Olá Luna! Pode me ajudar com meu projeto da BraganTec?", "remetente": "user", "criado_em": "2026-05-10T11:00:00"},
            {"id": "msg-002", "conteudo": "Claro! Vou carregar as regras da BraganTec e te ajudar passo a passo.", "remetente": "luna", "criado_em": "2026-05-10T11:00:30"},
        ])

        session.commit()


@contextmanager
def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
